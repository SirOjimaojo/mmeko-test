import React from 'react';
import Chat from './components/Chat';
import VideoCall from './components/VideoCall';
import AudioCall from './components/AudioCall';

const App: React.FC = () => {
  return (
    <div>
      <h1>Chat and Call Application</h1>
      <Chat />
      <VideoCall />
      <AudioCall />
    </div>
  );
};

export default App;
